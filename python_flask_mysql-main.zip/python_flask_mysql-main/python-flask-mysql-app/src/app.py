from flask import Flask, render_template, request, redirect, url_for
import os
import database as db 
template_dir = os.path.dirname(os.path.abspath(os.path.dirname(__file__)))
template_dir = os.path.join(template_dir, 'src', 'templates')

app = Flask(__name__, template_folder = template_dir)

#Rutas de la aplicación
@app.route('/')
def home():
    cursor = db.database.cursor()
    cursor.execute("SELECT * FROM clients")
    myresult = cursor.fetchall()
    #Convertir los datos a diccionario
    insertObject = []
    columnNames = [column[0] for column in cursor.description]
    for record in myresult:
        insertObject.append(dict(zip(columnNames, record)))
    cursor.close()
    return render_template('index.html', data=insertObject)

#Ruta para guardar usuarios en la bdd
@app.route('/user', methods=['POST'])
def addUser():
    
    nombre = request.form['nombre']
    precio = request.form['precio']
    horas= request.form['horas']
    nivel = request.form['nivel']
    profesor = request.form['profesor']
    institucion = request.form['institucion']

    fecha_inscripcion = request.form['fecha_inscripcion']
    
    fecha_inscripcionF = request.form['fecha_inscripcionF']

    fecha_inicio = request.form['fecha_inicio']
    fecha_cierre = request.form['fecha_cierre']

    num_Alumnos = request.form['num_Alumnos']
    modalidad = request.form['modalidad']

    descripcion = request.form['descripcion']

    if nombre and precio:
        cursor = db.database.cursor()
        sql = "INSERT INTO clients ( nombre, precio,horas,nivel,profesor,institucion,fecha_inscripcion,fecha_inscripcionF,fechainicio,fechacierre,num_Alumnos,modalidad,descripcion) VALUES ( %s, %s,%s, %s,%s, %s,%s, %s,%s, %s,%s, %s,%s)"
        data = ( nombre, precio,horas,nivel,profesor,institucion,fecha_inscripcion,fecha_inscripcionF,fechainicio,fechacierre,num_Alumnos,modalidad,descripcion)
        cursor.execute(sql, data)
        db.database.commit()
    return redirect(url_for('home'))

@app.route('/delete/<string:id>')
def delete(id):
    cursor = db.database.cursor()
    sql = "DELETE FROM clients WHERE id=%s"
    data = (id,)
    cursor.execute(sql, data)
    db.database.commit()
    return redirect(url_for('home'))

@app.route('/edit/<string:id>', methods=['POST'])
def edit(id):
    nombre = request.form['nombre']
    precio = request.form['precio']

    horas= request.form['horas']
    nivel = request.form['nivel']

    profesor = request.form['profesor']
    institucion = request.form['institucion']

    fecha_inscripcion = request.form['fecha_inscripcion']
    
    fecha_inscripcionF = request.form['fecha_inscripcionF']

    fecha_inicio = request.form['fecha_inicio']
    fecha_cierre = request.form['fecha_cierre']

    num_Alumnos = request.form['num_Alumnos']
    modalidad = request.form['modalidad']

    descripcion = request.form['descripcion']

    if nombre and precio and horas:
        cursor = db.database.cursor()
        sql = "UPDATE clients SET  nombre = %s, precio= %s,horas= %s,nivel= %s,profesor= %s,institucion= %s,fecha_inscripcion= %s,fecha_inscripcionF= %s,fecha_inicio= %s,fecha_cierre= %s,num_Alumnos= %s,modalidad= %s,descripcion= %s WHERE id = %s"
        data = ( nombre, precio,horas,nivel,profesor,institucion,fecha_inscripcion,fecha_inscripcionF,fecha_inicio,fecha_cierre,num_Alumnos,modalidad,descripcion, id)
        cursor.execute(sql, data)
        db.database.commit()
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True, port=4000)